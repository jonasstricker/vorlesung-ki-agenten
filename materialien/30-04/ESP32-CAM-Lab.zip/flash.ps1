<#
=====================================================================
  ESP32-CAM Lab  -  Ein-Klick Setup & Flash (Windows / PowerShell)
=====================================================================
  Macht ALLES automatisch, damit Studierende sich nur um den
  Sensor kuemmern muessen:
    1. Laedt arduino-cli portabel nach .\tools  (kein winget noetig)
    2. Installiert den ESP32-Core (einmalig, kann dauern)
    3. Erkennt den COM-Port des ESP32 automatisch
    4. Kompiliert den Sketch  .\esp32_cam_lab
    5. Spielt die Firmware auf
    6. Liest die Startmeldung (zeigt WLAN + IP)

  AUFRUF (im Projektordner):
      ./flash.ps1
  Optional festen Port erzwingen:
      ./flash.ps1 -Port COM4
=====================================================================
#>

param(
    [string]$Port = "",
    [string]$Fqbn = "esp32:esp32:esp32cam",
    [string]$Sketch = "esp32_cam_lab"
)

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

function Write-Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }

$Tools = Join-Path $PSScriptRoot "tools"
$Cli   = Join-Path $Tools "arduino-cli.exe"

# ---------------------------------------------------------------
# 1) arduino-cli portabel sicherstellen
# ---------------------------------------------------------------
Write-Step "Pruefe arduino-cli"
if (-not (Test-Path $Cli)) {
    Write-Host "arduino-cli nicht gefunden -> lade portable Version..."
    New-Item -ItemType Directory -Force -Path $Tools | Out-Null
    $zip = Join-Path $Tools "arduino-cli.zip"
    Invoke-WebRequest -Uri "https://downloads.arduino.cc/arduino-cli/arduino-cli_latest_Windows_64bit.zip" -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath $Tools -Force
    Remove-Item $zip -Force
}
& $Cli version | Out-Host

# ---------------------------------------------------------------
# 2) ESP32-Core sicherstellen
# ---------------------------------------------------------------
Write-Step "Pruefe ESP32-Core"
$coreList = (& $Cli core list 2>$null) -join "`n"
if ($coreList -notmatch "esp32:esp32") {
    Write-Host "ESP32-Core wird installiert (einmalig, ~600 MB, bitte warten)..."
    & $Cli config init --overwrite | Out-Null
    & $Cli config add board_manager.additional_urls "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json"
    & $Cli core update-index
    & $Cli core install esp32:esp32
} else {
    Write-Host "ESP32-Core bereits installiert."
}

# ---------------------------------------------------------------
# 3) COM-Port automatisch erkennen
# ---------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($Port)) {
    Write-Step "Suche ESP32 am COM-Port"
    # esptool liefert bei Nicht-ESP32-Ports Exit-Code != 0 -> nicht als Fehler werten
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $found = $null
    foreach ($p in [System.IO.Ports.SerialPort]::GetPortNames()) {
        Write-Host "  Teste $p ..." -NoNewline
        try {
            $out = (& esptool --port $p --before default-reset --after hard-reset chip-id 2>&1) | Out-String
        } catch {
            $out = ""
        }
        if ($out -match "Connected to ESP32") {
            Write-Host " ESP32 gefunden!" -ForegroundColor Green
            $found = $p
            break
        } else {
            Write-Host " nichts."
        }
    }
    $ErrorActionPreference = $prevEAP
    if (-not $found) {
        throw "Kein ESP32 gefunden. USB/Hub pruefen, Treiber (CH340/CP2102) installieren, anderen USB-Port testen."
    }
    $Port = $found
}
Write-Host "Verwende Port: $Port" -ForegroundColor Green

# ---------------------------------------------------------------
# 4) Kompilieren
# ---------------------------------------------------------------
Write-Step "Kompiliere Sketch ($Sketch)"
& $Cli compile --fqbn $Fqbn ".\$Sketch"

# ---------------------------------------------------------------
# 5) Aufspielen
# ---------------------------------------------------------------
Write-Step "Spiele Firmware auf $Port"
& $Cli upload -p $Port --fqbn $Fqbn ".\$Sketch"

# ---------------------------------------------------------------
# 6) Startmeldung lesen
# ---------------------------------------------------------------
Write-Step "Lese Startmeldung vom ESP32"
try {
    $sp = New-Object System.IO.Ports.SerialPort($Port, 115200)
    $sp.ReadTimeout = 1500
    $sp.Open()
    Start-Sleep -Milliseconds 200
    $sp.DtrEnable = $false; $sp.RtsEnable = $true; Start-Sleep -Milliseconds 100
    $sp.RtsEnable = $false
    $deadline = (Get-Date).AddSeconds(6)
    while ((Get-Date) -lt $deadline) {
        try { Write-Host ("  " + $sp.ReadLine()) } catch {}
    }
    $sp.Close()
} catch {
    Write-Host "Hinweis: Serielle Ausgabe konnte nicht gelesen werden (Port evtl. belegt)." -ForegroundColor Yellow
}

Write-Host "`nFERTIG!" -ForegroundColor Green
Write-Host "WLAN:    ESP32-CAM-<deinNachname>  (siehe #define NACHNAME im Sketch)"
Write-Host "Passwort: 12345678"
Write-Host "Webseite: http://192.168.4.1"
