/*
 * =====================================================================
 *  ESP32-CAM LAB FIRMWARE
 *  Eigener WLAN Access Point + Live-Kamerabild + Sensor-Platzhalter
 * =====================================================================
 *
 *  Board in der Arduino IDE: "AI Thinker ESP32-CAM"
 *
 *  WAS MACHT DIESE FIRMWARE?
 *   1. Der ESP32 spannt ein EIGENES WLAN auf (Access Point).
 *      -> SSID:     ESP32-CAM-<NACHNAME>   (siehe #define NACHNAME)
 *      -> Passwort: 12345678
 *   2. Verbinde dich mit diesem WLAN (Handy/PC) und oeffne im
 *      Browser:  http://192.168.4.1
 *   3. Du siehst das Live-Kamerabild, Datum, Uhrzeit und
 *      Platzhalter fuer Temperatur / Luftfeuchtigkeit.
 *
 *  SENSOR / OLED KOMMEN SPAETER:
 *   - Die I2C-Pins (SDA = GPIO14, SCL = GPIO15) sind bereits
 *     vordefiniert. Sensor (BME680) und OLED-Display (SSD1306)
 *     teilen sich denselben I2C-Bus (unterschiedliche Adressen).
 *   - Aktuell liefert /sensor nur Platzhalter-Werte (connected=false).
 * =====================================================================
 */

#include "esp_camera.h"
#include <WiFi.h>
#include "esp_http_server.h"

// ============================================================
//  1) WLAN ACCESS POINT
// ============================================================
//  >>> STUDENT: Trage hier deinen NACHNAMEN ein! <<<
//  Damit bekommt JEDES Board einen eigenen WLAN-Namen und es gibt
//  keine Konflikte, wenn mehrere Boards gleichzeitig laufen.
//  Beispiel: "Mueller"  ->  WLAN heisst dann "ESP32-CAM-Mueller"
#define NACHNAME "Lab"

// Daraus wird automatisch der WLAN-Name gebaut (nicht aendern):
const char* AP_SSID = "ESP32-CAM-" NACHNAME;  // z.B. ESP32-CAM-Mueller
const char* AP_PASS = "12345678";              // einfaches Passwort (min. 8 Zeichen)

// ============================================================
//  2) KAMERA-PINS  -  AI Thinker ESP32-CAM (vordefiniert)
// ============================================================
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ============================================================
//  3) I2C-PINS FUER SPAETER  (OLED-Display + BME680 Sensor)
// ============================================================
//  Diese Pins sind frei, weil keine SD-Karte benutzt wird.
//  -> OLED SSD1306 128x64 : I2C-Adresse 0x3C
//  -> BME680 Sensor       : I2C-Adresse 0x76 oder 0x77
//  Beide kommen an denselben I2C-Bus:
//      SDA -> GPIO 14
//      SCL -> GPIO 15
//      VCC -> 3.3V
//      GND -> GND
#define I2C_SDA 14
#define I2C_SCL 15

// Eingebaute Blitz-LED (optional)
#define LED_FLASH 4

// ============================================================
//  Stream-Konstanten (MJPEG)
// ============================================================
#define PART_BOUNDARY "123456789000000000000987654321"
static const char* STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* STREAM_BOUNDARY     = "\r\n--" PART_BOUNDARY "\r\n";
static const char* STREAM_PART         = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

// Zwei Server: Port 80 = Webseite/API, Port 81 = Kamera-Stream
httpd_handle_t web_httpd    = NULL;
httpd_handle_t stream_httpd = NULL;

// ============================================================
//  Eingebettete Webseite (wird vom ESP32 direkt ausgeliefert)
//  -> KEIN Internet noetig, alles inline (AP-Modus!)
// ============================================================
static const char PAGE_INDEX[] PROGMEM = R"HTMLPAGE(
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ESP32-CAM Lab</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',Tahoma,sans-serif;}
  body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);color:#ecf0f1;min-height:100vh;padding:16px;}
  .wrap{max-width:780px;margin:0 auto;}
  header{text-align:center;margin-bottom:18px;}
  header h1{font-size:1.5rem;}
  .clock{margin-top:6px;font-size:1.1rem;color:#bdc3c7;}
  .cam{background:rgba(255,255,255,.07);border-radius:16px;padding:12px;text-align:center;margin-bottom:18px;}
  .cam img{width:100%;max-width:640px;border-radius:10px;background:#000;}
  .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;}
  .card{background:rgba(255,255,255,.07);border-radius:16px;padding:20px;text-align:center;border-left:4px solid #3498db;}
  .card.temp{border-color:#e74c3c;}
  .card.hum{border-color:#3498db;}
  .ico{font-size:1.8rem;}
  .val{font-size:2.2rem;font-weight:700;}
  .unit{color:#bdc3c7;}
  .lbl{font-size:.8rem;color:#95a5a6;text-transform:uppercase;letter-spacing:1px;margin-top:4px;}
  .note{margin-top:8px;font-size:.75rem;color:#f39c12;}
  footer{text-align:center;color:#7f8c8d;font-size:.8rem;margin-top:18px;}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <h1>&#128247; ESP32-CAM Lab</h1>
      <div class="clock" id="clock">--:--:--</div>
    </header>

    <div class="cam">
      <img id="stream" src="" alt="Kamerabild laedt...">
    </div>

    <div class="cards">
      <div class="card temp">
        <div class="ico">&#127777;</div>
        <div><span class="val" id="temp">--</span> <span class="unit">&deg;C</span></div>
        <div class="lbl">Temperatur</div>
        <div class="note" id="tnote">Sensor folgt</div>
      </div>
      <div class="card hum">
        <div class="ico">&#128167;</div>
        <div><span class="val" id="hum">--</span> <span class="unit">%</span></div>
        <div class="lbl">Luftfeuchtigkeit</div>
        <div class="note" id="hnote">Sensor folgt</div>
      </div>
    </div>

    <footer>ESP32-CAM &bull; Access Point aktiv</footer>
  </div>

<script>
  // Kamera-Stream laeuft auf Port 81
  document.getElementById('stream').src =
      'http://' + location.hostname + ':81/stream';

  // Datum + Uhrzeit (aus dem Browser)
  function tick(){
    var d = new Date();
    document.getElementById('clock').textContent =
      d.toLocaleDateString('de-DE') + '  ' + d.toLocaleTimeString('de-DE');
  }
  setInterval(tick, 1000); tick();

  // Sensorwerte abfragen (aktuell Platzhalter)
  async function poll(){
    try{
      var r = await fetch('/sensor', {cache:'no-store'});
      var s = await r.json();
      if(s.connected){
        document.getElementById('temp').textContent = s.temperature.toFixed(1);
        document.getElementById('hum').textContent  = s.humidity.toFixed(1);
        document.getElementById('tnote').textContent = '';
        document.getElementById('hnote').textContent = '';
      }else{
        document.getElementById('temp').textContent = '--';
        document.getElementById('hum').textContent  = '--';
      }
    }catch(e){ /* ignorieren */ }
  }
  setInterval(poll, 3000); poll();
</script>
</body>
</html>
)HTMLPAGE";

// ============================================================
//  HTTP-Handler: Startseite
// ============================================================
static esp_err_t index_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, (const char *)PAGE_INDEX, strlen(PAGE_INDEX));
}

// ============================================================
//  HTTP-Handler: Sensordaten (JSON)  -  aktuell Platzhalter
// ============================================================
static esp_err_t sensor_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");

  // ----- SPAETER: hier echte BME680-Werte einsetzen -----
  // Beispiel (wenn Sensor angeschlossen):
  //   String json = "{\"temperature\":" + String(t,1) +
  //                 ",\"humidity\":" + String(h,1) +
  //                 ",\"connected\":true}";
  const char* json = "{\"temperature\":null,\"humidity\":null,\"connected\":false}";
  return httpd_resp_send(req, json, strlen(json));
}

// ============================================================
//  HTTP-Handler: Einzelbild (JPEG)
// ============================================================
static esp_err_t capture_handler(httpd_req_t *req) {
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    httpd_resp_send_500(req);
    return ESP_FAIL;
  }
  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=capture.jpg");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  esp_err_t res = httpd_resp_send(req, (const char *)fb->buf, fb->len);
  esp_camera_fb_return(fb);
  return res;
}

// ============================================================
//  HTTP-Handler: Live-Stream (MJPEG)  -  laeuft auf Port 81
// ============================================================
static esp_err_t stream_handler(httpd_req_t *req) {
  camera_fb_t *fb = NULL;
  esp_err_t res = ESP_OK;
  char part_buf[64];

  res = httpd_resp_set_type(req, STREAM_CONTENT_TYPE);
  if (res != ESP_OK) return res;
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

  while (true) {
    fb = esp_camera_fb_get();
    if (!fb) {
      res = ESP_FAIL;
    } else {
      size_t hlen = snprintf(part_buf, sizeof(part_buf), STREAM_PART, fb->len);
      res = httpd_resp_send_chunk(req, STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));
      if (res == ESP_OK) res = httpd_resp_send_chunk(req, part_buf, hlen);
      if (res == ESP_OK) res = httpd_resp_send_chunk(req, (const char *)fb->buf, fb->len);
      esp_camera_fb_return(fb);
    }
    if (res != ESP_OK) break;
  }
  return res;
}

// ============================================================
//  Server starten
// ============================================================
void startServers() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 80;
  config.ctrl_port   = 32080;

  httpd_uri_t index_uri   = { "/",        HTTP_GET, index_handler,   NULL };
  httpd_uri_t sensor_uri  = { "/sensor",  HTTP_GET, sensor_handler,  NULL };
  httpd_uri_t capture_uri = { "/capture", HTTP_GET, capture_handler, NULL };

  if (httpd_start(&web_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(web_httpd, &index_uri);
    httpd_register_uri_handler(web_httpd, &sensor_uri);
    httpd_register_uri_handler(web_httpd, &capture_uri);
  }

  // Zweiter Server fuer den Stream (Port 81)
  config.server_port = 81;
  config.ctrl_port   = 32081;
  httpd_uri_t stream_uri = { "/stream", HTTP_GET, stream_handler, NULL };
  if (httpd_start(&stream_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(stream_httpd, &stream_uri);
  }
}

// ============================================================
//  Kamera initialisieren
// ============================================================
bool initCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size   = FRAMESIZE_VGA;     // 640x480
  config.pixel_format = PIXFORMAT_JPEG;
  config.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location  = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 12;
  config.fb_count     = 1;

  if (psramFound()) {
    config.jpeg_quality = 10;
    config.fb_count     = 2;
    // GRAB_WHEN_EMPTY statt LATEST -> verhindert "cam_hal: FB-OVF"-Spam im Leerlauf
    config.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
  } else {
    config.frame_size  = FRAMESIZE_CIF;    // weniger RAM ohne PSRAM
    config.fb_location = CAMERA_FB_IN_DRAM;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Kamera-Init fehlgeschlagen: 0x%x\n", err);
    return false;
  }
  return true;
}

// ============================================================
//  SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== ESP32-CAM Lab startet ===");

  pinMode(LED_FLASH, OUTPUT);
  digitalWrite(LED_FLASH, LOW);

  // Kamera starten
  if (!initCamera()) {
    Serial.println("FEHLER: Kamera nicht gefunden. Verkabelung/Modul pruefen.");
  } else {
    Serial.println("Kamera OK.");
  }

  // ----- SPAETER: I2C fuer OLED + Sensor aktivieren -----
  // #include <Wire.h>
  // Wire.begin(I2C_SDA, I2C_SCL);

  // Eigenen WLAN Access Point aufspannen
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  IPAddress ip = WiFi.softAPIP();

  Serial.println("------------------------------------");
  Serial.printf("WLAN-Name (SSID): %s\n", AP_SSID);
  Serial.printf("WLAN-Passwort   : %s\n", AP_PASS);
  Serial.print ("Webseite oeffnen: http://");
  Serial.println(ip);
  Serial.println("------------------------------------");

  startServers();
  Serial.println("Webserver laeuft.");
}

void loop() {
  // Alles laeuft in den HTTP-Handlern.
  delay(1000);
}
