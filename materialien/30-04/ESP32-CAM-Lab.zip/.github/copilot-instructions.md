# Copilot / KI-Agent Instructions – ESP32-CAM Lab

Dieses Projekt wird in einer **KI-Vorlesung** verwendet. Der KI-Agent übernimmt
**das komplette Setup und Flashen**, damit Studierende sich **nur auf das
Einbauen eines Sensors** (BME680, später OLED) konzentrieren.

## Goldene Regel
Wenn ein:e Student:in sagt „Board angeschlossen“, „flashen“, „aufspielen“,
„läuft nicht“ → führe den **verifizierten Flash-Workflow** unten aus, ohne lange
Rückfragen. Halte nur an, wenn Hardware fehlt oder ein echter Fehler auftritt.

## Verifizierter Flash-Workflow (bevorzugt: Skript)
1. **Bevorzugt** das fertige Skript ausführen:
   - Windows: `./flash.ps1`
   - Linux/macOS: `./flash.sh`
   Das Skript erledigt: arduino-cli laden → ESP32-Core → Port-Erkennung →
   Compile → Upload → Startmeldung lesen.
2. Nur wenn das Skript fehlschlägt, die Einzelschritte manuell ausführen.

## Verifizierte Fakten (diese Umgebung)
- **FQBN:** `esp32:esp32:esp32cam`
- **Sketch-Ordner:** `esp32_cam_lab`
- **Chip:** ESP32-D0WD-V3, **Auto-Reset über RTS** → keine BOOT-Taste nötig.
- **Port-Erkennung:** Über alle COM-/tty-Ports iterieren und mit
  `esptool --port <p> --before default-reset --after hard-reset chip-id` testen.
  Der Port mit „Connected to ESP32“ ist der richtige.
  (Beobachtet: COM3 = Phantom, COM4 = echter ESP32.)

## Bekannte Setup-Hürden + Lösungen
- **`winget` ist per Group Policy gesperrt** → NICHT winget nutzen.
  Stattdessen arduino-cli **portabel** nach `./tools/` laden (das Skript macht das).
- `esptool` und `python` sind bereits vorhanden.
- **ESP32-Core ist ~673 MB** → Installation kann mehrere Minuten dauern; abwarten.
- Upload-Fehler „No serial data received“ → anderer Port/aktiver USB-Hub,
  CH340-/CP2102-Treiber prüfen.

## Manuelle Einzelschritte (Fallback, Windows)
```powershell
$cli = ".\tools\arduino-cli.exe"
& $cli compile --fqbn esp32:esp32:esp32cam .\esp32_cam_lab
& $cli upload -p COM4 --fqbn esp32:esp32:esp32cam .\esp32_cam_lab
```

## Was Studierende selbst tun (Fokus)
- **Eigenen WLAN-Namen** setzen: in `esp32_cam_lab.ino` die Zeile
  `#define NACHNAME "Lab"` auf den eigenen Nachnamen ändern
  (verhindert WLAN-Konflikte bei mehreren Boards).
- Sensor **BME680** an I2C anschließen: **SDA=GPIO14, SCL=GPIO15, 3.3V, GND**.
- In `esp32_cam_lab/esp32_cam_lab.ino`:
  - `#include <Wire.h>` + `Wire.begin(I2C_SDA, I2C_SCL);` in `setup()` aktivieren.
  - Im `sensor_handler` echte Werte statt `null`/`connected:false` liefern.
- Optional OLED SSD1306 (I2C 0x3C) am selben Bus.

## Erfolg sieht so aus
Serielle Ausgabe @115200 zeigt:
```
Kamera OK.
WLAN-Name (SSID): ESP32-CAM-<Nachname>
Webseite oeffnen: http://192.168.4.1
Webserver laeuft.
```
Dann: WLAN `ESP32-CAM-<Nachname>` (Passwort `12345678`) → Browser `http://192.168.4.1`.
