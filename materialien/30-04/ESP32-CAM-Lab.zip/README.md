# ESP32-CAM Lab – Schnellstart für Studierende

> **Ziel der Übung:** Du baust einen **Sensor** ein und liest Werte aus.
> Das **Setup und Flashen übernimmt der KI-Agent** – du musst dich darum
> **nicht** kümmern. Sag dem Agenten einfach „Board angeschlossen, bitte flashen“.

---

## 🚀 In 3 Schritten startklar

### 1. Board anschließen
ESP32-CAM per USB anstecken (über den Programmer / Adapter).
Falls möglich einen **aktiven USB-Hub** verwenden (stabiler beim Start).

### 1b. Eigenen WLAN-Namen setzen (wichtig bei mehreren Boards!)
Damit nicht alle Boards das gleiche WLAN aufspannen, trägst du deinen
**Nachnamen** ein. Öffne [esp32_cam_lab/esp32_cam_lab.ino](esp32_cam_lab/esp32_cam_lab.ino)
und ändere **nur diese eine Zeile**:
```cpp
#define NACHNAME "Lab"      // z.B. "Mueller"
```
Dein WLAN heißt dann automatisch **`ESP32-CAM-Mueller`**.

### 2. Flashen lassen
Sag dem KI-Agenten: **„Board angeschlossen, bitte flashen.“**
Der Agent macht alles automatisch. Alternativ selbst ausführen:

| System        | Befehl im Projektordner |
|---------------|-------------------------|
| Windows       | `./flash.ps1`           |
| Linux / macOS | `./flash.sh`            |

Das Skript erledigt **alles automatisch**:
arduino-cli laden → ESP32-Core installieren → COM-Port finden → kompilieren →
aufspielen → Startmeldung anzeigen. (Beim ersten Mal lädt es den ESP32-Core,
das dauert ein paar Minuten – danach geht es schnell.)

### 3. Webseite öffnen
1. Am Handy/PC ins WLAN **`ESP32-CAM-<deinNachname>`** (Passwort **`12345678`**).
2. Browser öffnen: **`http://192.168.4.1`**
3. Du siehst Live-Kamerabild, Datum/Uhrzeit und **Platzhalter** für Temperatur/Feuchte.

---

## 🎯 Deine Aufgabe: Sensor einbauen (BME680)

### Verkabelung (I2C – bereits im Code vorbereitet)

| BME680 | ESP32-CAM |
|--------|-----------|
| VCC    | 3.3V      |
| GND    | GND       |
| SDA    | GPIO 14   |
| SCL    | GPIO 15   |

### Code anpassen in [esp32_cam_lab/esp32_cam_lab.ino](esp32_cam_lab/esp32_cam_lab.ino)

1. Oben einbinden: `#include <Wire.h>` (und BME680-Bibliothek).
2. In `setup()` die vorbereitete Zeile aktivieren:
   ```cpp
   Wire.begin(I2C_SDA, I2C_SCL);
   ```
3. Im `sensor_handler` echte Werte zurückgeben statt der Platzhalter
   (`connected:true` + Temperatur/Feuchte). Die Stelle ist im Code markiert.
4. Neu flashen lassen → Werte erscheinen auf der Webseite.

> Optional später: OLED-Display **SSD1306** (I2C-Adresse `0x3C`) am **gleichen**
> Bus (SDA=GPIO14, SCL=GPIO15) für lokale Anzeige.

Benötigte Arduino-Bibliotheken:
`Adafruit BME680 Library` + `Adafruit Unified Sensor`
(für OLED zusätzlich `Adafruit SSD1306` + `Adafruit GFX Library`).

---

## 🧩 Projektstruktur

```
├── flash.ps1 / flash.sh          ← Ein-Klick Setup & Flash
├── esp32_cam_lab/
│   └── esp32_cam_lab.ino         ← Firmware (hier kommt dein Sensor rein)
├── webseite/                     ← läuft auch auf dem eigenen PC
│   ├── index.html / style.css / app.js
└── .github/copilot-instructions.md  ← Anweisungen für den KI-Agenten
```

Die Webseite ist **exportierbar**: Ordner `webseite/` kopieren, `index.html`
doppelklicken, oben IP `192.168.4.1` eingeben → läuft auf jedem Studenten-PC.

---

## 🆘 Wenn etwas klemmt
Sag dem KI-Agenten einfach, was passiert ist („läuft nicht“, „kein Port“). Häufige Fälle:

- **Kein Port gefunden** → anderen USB-Port/aktiven Hub testen; Treiber
  (CH340 oder CP2102) installieren.
- **Upload „No serial data received“** → Board neu einstecken, anderen Port nutzen.
- **Core-Installation dauert lange** → normal (~673 MB), einfach warten.
  Das wird **auf dem PC** installiert (Compiler/Werkzeuge), **nicht** auf den ESP32!
  Auf den ESP32 gehen nur **~1 MB** Firmware (siehe „32% von 4 MB Flash“).

Feste Vorgaben (vom Agenten verifiziert): FQBN `esp32:esp32:esp32cam`,
Auto-Reset über RTS (keine BOOT-Taste nötig).
