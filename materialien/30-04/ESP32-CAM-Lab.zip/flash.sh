#!/usr/bin/env bash
# =====================================================================
#  ESP32-CAM Lab  -  Ein-Klick Setup & Flash (Linux / macOS)
# =====================================================================
#  Macht ALLES automatisch, damit Studierende sich nur um den
#  Sensor kuemmern muessen:
#    1. Laedt arduino-cli portabel nach ./tools
#    2. Installiert den ESP32-Core (einmalig, kann dauern)
#    3. Erkennt den seriellen Port des ESP32 automatisch
#    4. Kompiliert den Sketch ./esp32_cam_lab
#    5. Spielt die Firmware auf
#
#  AUFRUF (im Projektordner):
#      chmod +x flash.sh   # einmalig
#      ./flash.sh
#  Optional festen Port erzwingen:
#      ./flash.sh /dev/ttyUSB0
# =====================================================================
set -e

cd "$(dirname "$0")"

FQBN="esp32:esp32:esp32cam"
SKETCH="esp32_cam_lab"
PORT="${1:-}"
TOOLS="./tools"
CLI="$TOOLS/arduino-cli"

step() { echo -e "\n=== $1 ==="; }

# ---------------------------------------------------------------
# 1) arduino-cli portabel sicherstellen
# ---------------------------------------------------------------
step "Pruefe arduino-cli"
if [ ! -x "$CLI" ]; then
  echo "arduino-cli nicht gefunden -> lade portable Version..."
  mkdir -p "$TOOLS"
  OS="$(uname -s)"
  ARCH="$(uname -m)"
  case "$OS" in
    Linux)  case "$ARCH" in
              x86_64|amd64) PKG="Linux_64bit" ;;
              aarch64|arm64) PKG="Linux_ARM64" ;;
              *) PKG="Linux_64bit" ;;
            esac ;;
    Darwin) case "$ARCH" in
              arm64) PKG="macOS_ARM64" ;;
              *) PKG="macOS_64bit" ;;
            esac ;;
    *) echo "Unbekanntes OS: $OS"; exit 1 ;;
  esac
  URL="https://downloads.arduino.cc/arduino-cli/arduino-cli_latest_${PKG}.tar.gz"
  curl -L "$URL" -o "$TOOLS/arduino-cli.tar.gz"
  tar -xzf "$TOOLS/arduino-cli.tar.gz" -C "$TOOLS"
  rm -f "$TOOLS/arduino-cli.tar.gz"
  chmod +x "$CLI"
fi
"$CLI" version

# ---------------------------------------------------------------
# 2) ESP32-Core sicherstellen
# ---------------------------------------------------------------
step "Pruefe ESP32-Core"
if ! "$CLI" core list 2>/dev/null | grep -q "esp32:esp32"; then
  echo "ESP32-Core wird installiert (einmalig, ~600 MB, bitte warten)..."
  "$CLI" config init --overwrite >/dev/null
  "$CLI" config add board_manager.additional_urls \
    "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json"
  "$CLI" core update-index
  "$CLI" core install esp32:esp32
else
  echo "ESP32-Core bereits installiert."
fi

# ---------------------------------------------------------------
# 3) Port automatisch erkennen (via arduino-cli board list)
# ---------------------------------------------------------------
if [ -z "$PORT" ]; then
  step "Suche ESP32 am seriellen Port"
  # Bevorzugt typische USB-Seriell-Ports
  for cand in /dev/ttyUSB* /dev/ttyACM* /dev/tty.usbserial* /dev/tty.SLAB* /dev/tty.wchusbserial*; do
    [ -e "$cand" ] || continue
    PORT="$cand"
    echo "Gefunden: $PORT"
    break
  done
  if [ -z "$PORT" ]; then
    echo "Kein serieller Port gefunden. USB/Hub pruefen, Treiber (CH340/CP2102) pruefen."
    echo "Verfuegbare Ports:"; "$CLI" board list
    exit 1
  fi
fi
echo "Verwende Port: $PORT"

# ---------------------------------------------------------------
# 4) Kompilieren
# ---------------------------------------------------------------
step "Kompiliere Sketch ($SKETCH)"
"$CLI" compile --fqbn "$FQBN" "./$SKETCH"

# ---------------------------------------------------------------
# 5) Aufspielen
# ---------------------------------------------------------------
step "Spiele Firmware auf $PORT"
"$CLI" upload -p "$PORT" --fqbn "$FQBN" "./$SKETCH"

echo ""
echo "FERTIG!"
echo "WLAN:     ESP32-CAM-<deinNachname>  (siehe #define NACHNAME im Sketch)"
echo "Passwort: 12345678"
echo "Webseite: http://192.168.4.1"
