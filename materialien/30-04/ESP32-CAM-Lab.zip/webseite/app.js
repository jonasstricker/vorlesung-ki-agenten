/* ========================================================
 *  ESP32-CAM Lab Dashboard  -  Logik
 * ======================================================== */

let espIp = '192.168.4.1';
let sensorInterval = null;
const SENSOR_RATE_MS = 3000;

/* ---------- Datum & Uhrzeit (Browser-Uhr) ---------- */
function updateClock() {
    const now = new Date();
    document.getElementById('dateText').textContent =
        now.toLocaleDateString('de-DE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('timeText').textContent =
        now.toLocaleTimeString('de-DE');
}

/* ---------- Verbindung herstellen ---------- */
function connect() {
    const input = document.getElementById('espIp').value.trim();
    if (!input) {
        alert('Bitte die IP-Adresse des ESP32 eingeben (Standard: 192.168.4.1).');
        return;
    }
    espIp = input;
    localStorage.setItem('esp32_ip', espIp);

    // Kamera-Stream laeuft auf Port 81
    const stream = document.getElementById('stream');
    stream.src = `http://${espIp}:81/stream`;

    // Overlay ausblenden sobald Bild laedt
    stream.onload = () => {
        document.getElementById('camOverlay').style.display = 'none';
        setStatus(true);
    };
    stream.onerror = () => {
        document.getElementById('camOverlay').style.display = 'flex';
        document.getElementById('camOverlay').textContent = 'Kamera nicht erreichbar';
        setStatus(false);
    };

    // Sensor-Polling starten
    if (sensorInterval) clearInterval(sensorInterval);
    pollSensor();
    sensorInterval = setInterval(pollSensor, SENSOR_RATE_MS);
}

/* ---------- Sensorwerte abrufen (aktuell Platzhalter) ---------- */
async function pollSensor() {
    try {
        const res = await fetch(`http://${espIp}/sensor`, {
            cache: 'no-store',
            signal: AbortSignal.timeout(4000)
        });
        const data = await res.json();
        setStatus(true);

        if (data.connected) {
            document.getElementById('tempValue').textContent = data.temperature.toFixed(1);
            document.getElementById('humValue').textContent = data.humidity.toFixed(1);
            document.getElementById('tempNote').textContent = '';
            document.getElementById('humNote').textContent = '';
        } else {
            document.getElementById('tempValue').textContent = '--';
            document.getElementById('humValue').textContent = '--';
            document.getElementById('tempNote').textContent = 'Sensor noch nicht angeschlossen';
            document.getElementById('humNote').textContent = 'Sensor noch nicht angeschlossen';
        }
        document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString('de-DE');
    } catch (e) {
        setStatus(false);
    }
}

/* ---------- Schnappschuss herunterladen ---------- */
function snapshot() {
    const url = `http://${espIp}/capture?t=${Date.now()}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = `esp32cam_${Date.now()}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

/* ---------- Verbindungsstatus-Anzeige ---------- */
function setStatus(connected) {
    const el = document.getElementById('connectionStatus');
    const dot = el.querySelector('.status-dot');
    const text = el.querySelector('.status-text');
    dot.className = 'status-dot ' + (connected ? 'connected' : 'disconnected');
    text.textContent = connected ? 'Verbunden' : 'Getrennt';
}

/* ---------- Start ---------- */
window.addEventListener('DOMContentLoaded', () => {
    updateClock();
    setInterval(updateClock, 1000);

    const saved = localStorage.getItem('esp32_ip');
    if (saved) document.getElementById('espIp').value = saved;
});
